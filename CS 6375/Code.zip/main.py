import os
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import pandas as pd
from math import log2, e
import numpy as np
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import GridSearchCV

datasets = ["enron1", "enron3", "enron4"]
classes = ["ham", "spam"]

def frame_datasets():
    for dataset in datasets:
        df = pd.DataFrame(columns=['text', 'label'])
        folder = os.path.join("Train", dataset)
        folder = os.path.join(folder, "train")
        for cl in classes:
            path = os.path.join(folder, cl)
            for file in os.listdir(path):
                text = open(os.path.join(path, file), encoding="ISO-8859-1").read().split()
                lab = 0 if cl == 'ham' else 1
                df.loc[len(df)] = [text, lab]
        df.to_csv("{}_training".format(dataset), index=False)

    for dataset in datasets:
        df = pd.DataFrame(columns=['text', 'label'])
        folder = os.path.join("Test", dataset)
        folder = os.path.join(folder, "test")
        for cl in classes:
            path = os.path.join(folder, cl)
            for file in os.listdir(path):
                text = ' '.join(open(os.path.join(path, file), encoding="ISO-8859-1").read().split())
                lab = 0 if cl =="ham" else 1
                df.loc[len(df)] = [text, lab]
        df.to_csv("{}_testing".format(dataset), index = False)

def count_vectorize(dataset, kind):
    df = pd.read_csv("{}_{}".format(dataset, kind))
    text = df['text']
    vectorizer = CountVectorizer(ngram_range=(1, 1), lowercase = True , stop_words =  'english')
    bag = vectorizer.fit_transform(text).toarray()
    vocab = vectorizer.get_feature_names_out()
    matrix =  pd.DataFrame((bag), columns=vocab)
    matrix['class_label'] = df['label']
    return matrix

def train_nb(train):
    prior1 = train['class_label'].sum()
    prior1 = prior1/len(train)
    prior0 = 1 - prior1
    ham_rows = train.loc[train['class_label']==0]
    spam_rows = train.loc[train['class_label']==1]
    ham_counts = ham_rows.sum()+1
    spam_counts = spam_rows.sum()+1
    denoms = ham_counts + spam_counts
    ham_conditionals = ham_counts/denoms
    spam_conditionals = spam_counts/denoms
    return prior0, ham_conditionals[:][:-1], prior1, spam_conditionals[:][:-1]


def classify_bow(row, ham_cond, spam_cond, prior0, prior1):
    log_prob_ham = row.dot(np.log(ham_cond)) + prior0
    log_prob_spam = row.dot(np.log(spam_cond)) + prior1
    return 0 if log_prob_ham > log_prob_spam else 1


def naive_bayes_bow():
    print("Using multinomial NB and BoW")
    print("----------------------------")
    for dataset in datasets:
        print("Vectorizing {} datasets".format(dataset))
        train_matrix = count_vectorize(dataset, 'training')
        test_matrix = count_vectorize(dataset, 'testing')
        common_cols = [col for col in train_matrix.columns if col in test_matrix.columns]
        train_matrix = train_matrix[common_cols]
        test_matrix = test_matrix[common_cols]
        print("Training on {}_training".format(dataset))
        prior0, ham_cond, prior1, spam_cond = train_nb(train_matrix)
        test_features = test_matrix.drop('class_label', axis=1)
        prior0 = log2(prior0)
        prior1 = log2(prior1)
        print("Testing on {}_testing".format(dataset))
        predictions = test_features.apply(classify_bow, axis=1, args=(ham_cond, spam_cond, prior0, prior1))
        accuracy = accuracy_score(test_matrix['class_label'], predictions)
        precision = precision_score(test_matrix['class_label'], predictions)
        recall = recall_score(test_matrix['class_label'], predictions)
        f1 = f1_score(test_matrix['class_label'], predictions)
        print("Accuracy: {}    Precision: {}    Recall: {}    F1: {}".format(accuracy, precision, recall, f1))
        print()

def discrete_nb():
    print("Using NB and Benoulli")
    print("----------------------------")
    for dataset in datasets:
        print("Vectorizing {} datasets".format(dataset))
        train_matrix = count_vectorize(dataset, 'training')
        test_matrix = count_vectorize(dataset, 'testing')
        train_matrix = (train_matrix > 0).astype(int)
        test_matrix = (test_matrix > 0).astype(int)
        common_cols = [col for col in train_matrix.columns if col in test_matrix.columns]
        train_matrix = train_matrix[common_cols]
        test_matrix = test_matrix[common_cols]
        print("Training on {}_training".format(dataset))
        print("Training on {}_training".format(dataset))
        prior0, ham_cond, prior1, spam_cond = train_nb(train_matrix)
        test_features = test_matrix.drop('class_label', axis=1)
        prior0 = log2(prior0)
        prior1 = log2(prior1)
        print("Testing on {}_testing".format(dataset))
        predictions = test_features.apply(classify_bow, axis=1, args=(ham_cond, spam_cond, prior0, prior1))
        accuracy = accuracy_score(test_matrix['class_label'], predictions)
        precision = precision_score(test_matrix['class_label'], predictions)
        recall = recall_score(test_matrix['class_label'], predictions)
        f1 = f1_score(test_matrix['class_label'], predictions)
        print("Accuracy: {}    Precision: {}    Recall: {}    F1: {}".format(accuracy, precision, recall, f1))
        print()

def gradient_descent(train, labels, alpha, lmda):
    weights = np.zeros(len(train.columns))
    predictions = 1 / (1 + np.exp(-train.dot(weights)))
    error = (labels - predictions)**2
    new_error = error.sum()
    prev_error = 0
    max_iter = 3000
    while abs(new_error - prev_error) > .0001 and max_iter > 0:
        gradient = (1/len(train)) * train.T.dot(predictions-labels)
        l2 = 2*lmda*weights
        gradient += l2
        weights = weights - alpha*gradient
        prev_error = new_error
        predictions = (1 / (1 + np.exp(-train.dot(weights))) > .5).astype(int)
        error = (labels - predictions) ** 2
        new_error = error.sum()
        max_iter -= 1
    return weights



def logistic_regression_bernoulli():
    print("Using Logistic Regression and Benoulli")
    print("----------------------------")
    for dataset in datasets:
        print("Vectorizing {} datasets".format(dataset))
        train_matrix = count_vectorize(dataset, 'training')
        test_matrix = count_vectorize(dataset, 'testing')
        train_matrix = (train_matrix > 0).astype(int)
        test_matrix = (test_matrix > 0).astype(int)
        common_cols = [col for col in train_matrix.columns if col in test_matrix.columns]
        train_matrix = train_matrix[common_cols]
        test_matrix = test_matrix[common_cols]
        print("Training on {}_training".format(dataset))
        print("Training on {}_training".format(dataset))
        train, train_val, labels, label_val = train_test_split(train_matrix.drop('class_label', axis=1),
                                                          train_matrix['class_label'], test_size=0.3, random_state=42)


        lambdas = [.01, .1, .001, 1, 10]
        best_lambda = 0
        best_alpha = 0
        best_accuracy = -1
        for lmda in lambdas:
            weights = gradient_descent(train, labels, .01, lmda)
            predictions = (1 / (1 + np.exp(-train_val.dot(weights)))>.5).astype(int)
            accuracy = accuracy_score(label_val, predictions)
            if accuracy > best_accuracy:
                best_lambda = lmda
                best_accuracy = accuracy

        weights = gradient_descent(train_matrix.drop('class_label', axis=1), train_matrix['class_label'], best_alpha, best_lambda )
        predictions = (1 / (1 + np.exp(-test_matrix.drop('class_label', axis=1).dot(weights))) > .5).astype(int)
        accuracy = accuracy_score(test_matrix['class_label'], predictions)
        precision = precision_score(test_matrix['class_label'], predictions)
        recall = recall_score(test_matrix['class_label'], predictions)
        f1 = f1_score(test_matrix['class_label'], predictions)
        print("Accuracy: {}    Precision: {}    Recall: {}    F1: {}".format(accuracy, precision, recall, f1))
        print()

def logistic_regression():
    print("Using Logistic Regression and BoW")
    print("----------------------------")
    for dataset in datasets:
        print("Vectorizing {} datasets".format(dataset))
        train_matrix = count_vectorize(dataset, 'training')
        test_matrix = count_vectorize(dataset, 'testing')
        common_cols = [col for col in train_matrix.columns if col in test_matrix.columns]
        train_matrix = train_matrix[common_cols]
        test_matrix = test_matrix[common_cols]
        print("Training on {}_training".format(dataset))
        print("Training on {}_training".format(dataset))
        train, train_val, labels, label_val = train_test_split(train_matrix.drop('class_label', axis=1),
                                                          train_matrix['class_label'], test_size=0.3, random_state=42)


        lambdas = [.01, .1, .001, 1, 10]
        best_lambda = 0
        best_alpha = 0
        best_error = 10000000000
        for lmda in lambdas:
            weights = gradient_descent(train, labels, .01, lmda)
            predictions = 1 / (1 + np.exp(-train_val.dot(weights)))
            error = (label_val - predictions) ** 2
            error = error.sum()
            if error < best_error:
                best_lambda = lmda
                best_error = error

        weights = gradient_descent(train_matrix.drop('class_label', axis=1), train_matrix['class_label'], best_alpha, best_lambda )
        predictions = (1 / (1 + np.exp(-test_matrix.drop('class_label', axis=1).dot(weights))) > .5).astype(int)
        accuracy = accuracy_score(test_matrix['class_label'], predictions)
        precision = precision_score(test_matrix['class_label'], predictions)
        recall = recall_score(test_matrix['class_label'], predictions)
        f1 = f1_score(test_matrix['class_label'], predictions)
        print("Accuracy: {}    Precision: {}    Recall: {}    F1: {}".format(accuracy, precision, recall, f1))
        print()

def sgd():
    print("Using SGD and BoW")
    print("----------------------------")
    for dataset in datasets:
        print("Vectorizing {} datasets".format(dataset))
        train_matrix = count_vectorize(dataset, 'training')
        test_matrix = count_vectorize(dataset, 'testing')
        common_cols = [col for col in train_matrix.columns if col in test_matrix.columns]
        train_matrix = train_matrix[common_cols]
        test_matrix = test_matrix[common_cols]
        print("Training on {}_training".format(dataset))
        print("Training on {}_training".format(dataset))
        param_grid = {
            'loss': ['squared_error'],
            'penalty': ['l2'],
            'alpha': [0.0001, 0.001, 0.01],
            'max_iter': [3000],
        }

        sgd = SGDClassifier()
        grid_search = GridSearchCV(sgd, param_grid, cv=5, scoring='accuracy', n_jobs=-1)

        grid_search.fit(train_matrix.drop('class_label', axis=1), train_matrix['class_label'])
        best_sgd = grid_search.best_estimator_
        predictions = best_sgd.predict(test_matrix.drop('class_label', axis=1))
        accuracy = accuracy_score(test_matrix['class_label'], predictions)
        precision = precision_score(test_matrix['class_label'], predictions)
        recall = recall_score(test_matrix['class_label'], predictions)
        f1 = f1_score(test_matrix['class_label'], predictions)
        print("Accuracy: {}    Precision: {}    Recall: {}    F1: {}".format(accuracy, precision, recall, f1))
        print()

def sgd_bern():
    print("Using SGD and Bernoulli")
    print("----------------------------")
    for dataset in datasets:
        print("Vectorizing {} datasets".format(dataset))
        train_matrix = count_vectorize(dataset, 'training')
        test_matrix = count_vectorize(dataset, 'testing')
        common_cols = [col for col in train_matrix.columns if col in test_matrix.columns]
        train_matrix = train_matrix[common_cols]
        test_matrix = test_matrix[common_cols]
        train_matrix = (train_matrix > 0).astype(int)
        test_matrix = (test_matrix > 0).astype(int)
        print("Training on {}_training".format(dataset))
        print("Training on {}_training".format(dataset))
        param_grid = {
            'loss': ['squared_error'],
            'penalty': ['l2'],
            'alpha': [0.0001, 0.001, 0.01],
            'max_iter': [3000],
        }

        sgd = SGDClassifier()
        grid_search = GridSearchCV(sgd, param_grid, cv=5, scoring='accuracy', n_jobs=-1)

        grid_search.fit(train_matrix.drop('class_label', axis=1), train_matrix['class_label'])
        best_sgd = grid_search.best_estimator_
        predictions = best_sgd.predict(test_matrix.drop('class_label', axis=1))
        accuracy = accuracy_score(test_matrix['class_label'], predictions)
        precision = precision_score(test_matrix['class_label'], predictions)
        recall = recall_score(test_matrix['class_label'], predictions)
        f1 = f1_score(test_matrix['class_label'], predictions)
        print("Accuracy: {}    Precision: {}    Recall: {}    F1: {}".format(accuracy, precision, recall, f1))
        print()


#frame_datasets()
naive_bayes_bow()
print()
discrete_nb()
print()
logistic_regression_bernoulli()
print()
logistic_regression()
print()
sgd()
print()
sgd_bern()

